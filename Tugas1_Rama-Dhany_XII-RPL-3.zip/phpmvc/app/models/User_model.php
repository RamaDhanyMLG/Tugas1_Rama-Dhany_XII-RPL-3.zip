<?php

class User_model {
    private $nama = 'Rama Dhany';

    public function getUser()
    {
        return $this->nama;
    }
}